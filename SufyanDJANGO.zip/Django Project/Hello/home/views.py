
from django.contrib import messages
from django.shortcuts import render, HttpResponse
from home.models import Contact
from datetime import datetime
from home.models import products
from home.models import User
from home.models import Advertisment
import django.contrib.auth
def index(request):
    return render(request, "index.html")
def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact(name=name, email=email, phone=phone, desc=desc, date = datetime.today())
        contact.save()
        messages.success(request, "Message has been sent.")
        
        
    return render(request, "contact.html")
def service(request):
    
    data = Contact.objects.all()
    
    stu = {
        "student_number": data
    }
    #return render_to_response("service.html", stu)
    return render(request, "service.html", stu)
def login(request):
    
    if request.method=="POST":
        N = request.POST['name']
        x=auth.authenticate(Name=N)
        return render(request, "about.html")
    else:
        return render(request, "login.html")
    
def about(request):
    return render(request, "about.html")


def text(request):
    
    ITEMS = products.objects.all()
    main = products.objects.filter(Name= "Nike Shoe 782")

    
    
    params = {
        "Items": ITEMS,
        "main":main,
    }
    
    #return render_to_response("service.html", stu)
    return render(request, "text.html", {'main':main, 'Items':ITEMS})


def b(request):
    try:
        if request.method=='POST':
            name = request.POST.get('name')
            passwrd = request.POST.get('passwrd')
            Name = User.objects.get(Fname=name)
            print(Name.Fname)
            print(Name.Passwrd)
            if Name.Fname == name and Name.Passwrd == passwrd:
                return HttpResponse(f"Hy {Name.Fname} wlecome back")
            else:
                return render(request, 'b.html')
    except Exception as e:
        return render(request, 'b.html', e)
    # Just for refernce
    """alpha = Contact.objects.filter(name=request.POST.get('name'))
        phone = Contact.objects.filter(name=request.POST.get('name'))
        if alpha and phone is not None:
            for i in alpha:
                if i.name == email and i.phone=="+92345252888":
                    print(i.id)
                    print(i.name)
                    print(i.phone)
                    print(i.desc)
                    return HttpResponse(f" Hy {i.name} welcome back!")
                else:
                    print("sorrry")
                
        else:
            print("soory")"""