from django.contrib import admin
from home.models import Contact
from home.models import products
from home.models import Advertisment
from home.models import User
# Register your models here.
admin.site.register(User)
admin.site.register(Contact)
admin.site.register(products)
admin.site.register(Advertisment)