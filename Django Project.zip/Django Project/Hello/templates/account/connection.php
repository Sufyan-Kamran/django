<? php
echo "Kamran Ahmed";
?>