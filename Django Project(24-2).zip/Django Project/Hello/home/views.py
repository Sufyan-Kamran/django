from django.contrib import messages
from django.shortcuts import render, HttpResponse
from home.models import Contact
from datetime import datetime
from home.models import products
def index(request):
    return render(request, "index.html")
def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact(name=name, email=email, phone=phone, desc=desc, date = datetime.today())
        contact.save()
        messages.success(request, "Message has been sent.")
        
        
    return render(request, "contact.html")
def service(request):
    
    data = Contact.objects.all()
    
    stu = {
        "student_number": data
    }
    #return render_to_response("service.html", stu)
    return render(request, "service.html", stu)
def login(request):
    return render(request, "login.html")


def text(request):
    
    ITEMS = products.objects.all()
    
    
    params = {
        "Items": ITEMS,
     
    }
    #return render_to_response("service.html", stu)
    return render(request, "text.html", params)